I am not responsible for any possible damage done to your or someone elses computer

run the bat to start the fake virus